package unishop.services;

import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Map;

import unishop.entities.Cashier;
import unishop.entities.Product;
import unishop.entities.ProductDetails;
import unishop.entities.Shop;
import unishop.exceptions.ValidationException;

public class ShopService {

	public void restockShop(Shop shop, Product product, int amount, float priceIncrPercentage,
			float priceDecrPercentage) {
		ProductDetails pDetails = null;
		for (ProductDetails pd : shop.getProducts()) {
			if (pd.getProduct().getName().equals(product.getName())) {
				pDetails = pd;
				pDetails.setAmount(pDetails.getAmount() + amount);
				pDetails.setPriceIncrPercentage(priceIncrPercentage);
				pDetails.setPriceDecrPercentage(priceDecrPercentage);
				break;
			}
		}
		if (pDetails == null) {
			pDetails = new ProductDetails(product, amount, priceIncrPercentage, priceDecrPercentage);
			shop.getProducts().add(pDetails);
		}

	}

	public void sellStock(Shop shop, Product product, int amount) {
		ProductDetails pDetails = null;
		for (ProductDetails pds : shop.getProducts()) {
			if (pds.getProduct().getName().equals(product.getName())) {
				pDetails = pds;
				validateProductSale(pDetails, amount);
				pDetails.setAmount(pDetails.getAmount() - amount);
				generateReceipt(shop, pDetails, amount);
				break;
			}
		}
		if (pDetails == null) {
			throw new ValidationException("Product not found");
		}

	}

	private void generateReceipt(Shop shop, ProductDetails pDetails, int amount) {
		// TODO Auto-generated method stub

	}

	private void validateProductSale(ProductDetails pDetails, int amount) {
		if (pDetails.getAmount() < amount) {
			throw new ValidationException("Insufficient amount");
		}
		if (pDetails.getProduct().getDateOfExp().isBefore(LocalDate.now())) {
			throw new ValidationException("Product has expired");
		}
	}

	public void writingNotes(int number, Cashier cashier, LocalDateTime date, Map<ProductDetails, Integer> products,
			double totalPrice) {
		try {
			FileWriter notes = new FileWriter("recept.txt");

		} catch (IOException e) {

			e.printStackTrace();
		}
	}
}
