package unishop.entities;

public enum StockCategory {
	FOOD,
	BEVERAGES
}
